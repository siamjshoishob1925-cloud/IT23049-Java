package ict._21.ClassNames;

public class CustomPrintClass {
    public static void pr(String msg) {
        System.out.println(msg);
    }
}
